﻿Public Class decision
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strProdId = Request.QueryString("ProdId")
        Dim ctrl As Control

        If strProdId <> "" Then
            ctrl = LoadControl("~/WebUserControls/SingleProduct.ascx")
        Else
            ctrl = LoadControl("~/WebUserControls/MultiProductListView.ascx")
        End If

        plhContent.Controls.Add(ctrl)
    End Sub

End Class