﻿Public Class singleProduct
    Inherits System.Web.UI.UserControl

End Class