﻿Imports System.Data.SqlClient

Public Class multiProduct
    Inherits System.Web.UI.UserControl
    Private strConn As String =
       ConfigurationManager.ConnectionStrings("cnn").ConnectionString

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            'Collecting query string values
            Dim strProdId As String = Request.QueryString("ProdId")
            Dim strCat As String = Request.QueryString("Cat")
            Dim strKey As String = Request.QueryString("Keywords")
            Dim strAny As Boolean = Convert.ToBoolean(Request.QueryString("&anyWords"))

            If strKey <> "" Then
                getSearchProducts(strKey, strAny)
            ElseIf strCat = "" AndAlso strProdId = "" Then
                getProducts("spGetFeaturedProducts")
            ElseIf strCat.ToLower = "home" Then
                getProducts("spGetFeaturedProducts")
            ElseIf strCat <> "" Then
                If strCat.Length > 2 Then
                    getProducts("GetProductsByCategory", strCat)
                Else
                    Response.Write("<h2>Unknown Category ... Please Try Again.</h2>")
                End If
            End If

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub

    Private Sub getSearchProducts(strKey As String, strAny As Boolean)
        Throw New NotImplementedException
    End Sub

    Private Sub getProducts(ByVal sproc As String, _
                            Optional ByVal cat As String = "", _
                            Optional ByVal keywords As String() = Nothing, _
                            Optional ByVal anywords As Boolean = False)
        Try
            Dim dr As SqlDataReader
            Dim cmd As SqlCommand

            Using conn As New SqlConnection(strConn)
                conn.Open()

                'Create command
                cmd = New SqlCommand(sproc, conn)
                cmd.CommandType = CommandType.StoredProcedure
                If cat <> "" Then
                    cmd.Parameters.AddWithValue("@Cat", cat)
                ElseIf keywords IsNot Nothing Then

                End If

                'Create Datareader
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)

                If dr.HasRows Then
                    dlProducts.DataSource = dr
                    dlProducts.DataBind()
                Else
                    Response.Write("<h3>No Results Found</h3>")
                End If

            End Using
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub

End Class