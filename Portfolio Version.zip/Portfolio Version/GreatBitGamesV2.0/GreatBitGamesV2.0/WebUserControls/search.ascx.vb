﻿Public Class search
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim x As TextBox = DirectCast(FindControl("txtSearch"), TextBox)
        Dim y As CheckBox = DirectCast(FindControl("blnAllWords"), CheckBox)
        If x.Text = "" Then
            Exit Sub
        Else
            Dim strSearch As String = Server.HtmlEncode(x.Text)
            Dim strCheckbox As String = Server.HtmlEncode(y.Checked)
            Response.Redirect("default.aspx?SearchWord=" + strSearch + "&allwords=" & y.Checked)
        End If
    End Sub
End Class