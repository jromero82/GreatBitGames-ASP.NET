﻿Imports System.Data.SqlClient

Public Class multiProductListView
    Inherits System.Web.UI.UserControl
    Private strConn As String = ConfigurationManager.ConnectionStrings("cnn").ConnectionString

    Private Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Try
                Dim strSearchWord As String = Request.QueryString("SearchWord")
                Dim strQstring As String = Request.QueryString("category")

                Dim strProdId As String = Request.QueryString("ProdID")
                If strProdId <> "" Then
                    Me.Visible = False
                    Exit Sub
                End If
                If strQstring = Nothing Then
                    strQstring = "home"
                End If

                If strSearchWord <> "" Then
                    Dim blnCheck As Boolean = Request.QueryString("allwords")
                    ShowSearch(strSearchWord, blnCheck)
                Else
                    If strQstring = "home" Then
                        ShowFeatured()
                    Else
                        getItems(strQstring)
                    End If
                End If
            Catch ex As Exception
                lblError.Text = "<h3>An unexpected error has occurred</h3>"
            End Try

        End If

        
    End Sub
    Private Sub ShowFeatured()

        Try

            lsvMultiProduct.DataSourceID = "sqlGetFeatured"
            lsvMultiProduct.DataBind()

        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub
    Private Sub getItems(ByVal category As String)

        Try

            lsvMultiProduct.DataSourceID = "sqlGetProdByCat"
            lsvMultiProduct.DataBind()

        Catch ex As Exception
            lblError.Text = "An error has occurred " & ex.Message.ToString
        End Try

    End Sub
    Private Sub ShowSearch(ByVal strSearchWord As String, ByVal blnChecked As Boolean)
        Try

            Dim strArray As Array = strSearchWord.Split(" ")
            Dim intSize As Integer = strArray.Length

            'Add Parameters
            For i = 1 To intSize
                sqlSearchCatalog.SelectParameters.Add("Word" + i.ToString, strArray(i - 1))
            Next

            lsvMultiProduct.DataSourceID = "sqlSearchCatalog"
            lsvMultiProduct.DataBind()


        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub
End Class
